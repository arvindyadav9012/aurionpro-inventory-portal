CCR STRUCTURE UPDATE

1. Existing AURION PRO / NMRC INVENTORY branding restored on login page.
2. CCR Management is one main navigation item with dropdown:
   - CCR Management / Final CCR Summary
   - CCR Failed Transaction Summary
   - CCR Success Transaction Summary
   - Failed Transaction Reply to Customer
   - Final Summary
3. Existing User Management now includes a CCR Role / Permission selector:
   - CCR Admin
   - CCR Manager
   - CCR User
   - CCR Reply User
   - CCR View Only
4. CCR permissions apply only to CCR Management and do not replace existing portal roles.
5. Session auto-logout is set to 3 minutes of inactivity.
6. Login screen remains a single fitted viewport on mobile/desktop.
7. Existing data tables and D1/API schema are not deleted or migrated by this update.
